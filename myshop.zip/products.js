import {db} from "./firebase.js";

import {
collection,
addDoc,
getDocs
}
from 
"https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";


// Seller product add

export async function addProduct(name,price){

await addDoc(
collection(db,"products"),
{
name:name,
price:price
}
);

alert("Product Added ✅");

}


// Products show

export async function showProducts(){

let box=document.getElementById("products");

box.innerHTML="";


let data=await getDocs(
collection(db,"products")
);


data.forEach(doc=>{

let p=doc.data();


box.innerHTML+=`

<div class="card">

<h2>${p.name}</h2>

<p>₹${p.price}</p>

<button>
Buy Now
</button>

</div>

`;

});

}