function checkAdmin(){

let role =
localStorage.getItem("role");


if(role !== "admin"){

alert("Access Denied ❌");

window.location.href="index.html";

}

}



function loginAdmin(){

let pass =
document.getElementById("password").value;


if(pass=="admin123"){

localStorage.setItem(
"role",
"admin"
);


alert("Admin Login Successful ✅");


window.location.href="admin.html";


}

else{

alert("Wrong Password ❌");

}

}